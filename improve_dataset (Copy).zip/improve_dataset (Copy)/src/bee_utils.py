from pathlib import Path
import numpy as np
import csv
import math
import cv2


def bee_cutout(bee_id: int, frame_id: int, TRAJECTORY_DIR: Path, VIDEO_PATH: Path, cutout_size: int = 100) -> np.ndarray:
    """
    Return a square BGR image cutout centered on bee_id at frame_id.

    Parameters
    ----------
    bee_id : int
        Bee identifier; bee_id=7 corresponds to '000007.txt'.
    frame_id : int
        Frame index used in the trajectory file and MP4.
    cutout_size : int
        Width and height of the output patch. Default: 100.

    Returns
    -------
    np.ndarray
        BW image with shape (cutout_size, cutout_size).
        Out-of-frame regions are padded with black pixels.

    Raises
    ------
    FileNotFoundError
        If the trajectory file or MP4 does not exist.
    ValueError
        If no tracking position exists for this bee/frame, or the
        requested video frame cannot be read.
    """
    trajectory_path = TRAJECTORY_DIR / f"{bee_id:06d}.txt"

    if not trajectory_path.is_file():
        raise FileNotFoundError(f"Trajectory file not found: {trajectory_path}")
    if not VIDEO_PATH.is_file():
        raise FileNotFoundError(f"Video file not found: {VIDEO_PATH}")

    # Find the bee position in its trajectory file.
    position = None
    with trajectory_path.open("r", newline="") as f:
        reader = csv.reader(f, skipinitialspace=True)

        for row in reader:
            if not row or row[0].strip().startswith("#"):
                continue

            # Expected row:
            # frame_id, pos_x, pos_y, object_class, orientation_angle
            if int(row[0]) == frame_id:
                position = (float(row[1]), float(row[2]))
                break

    if position is None:
        raise ValueError(
            f"No position found for bee {bee_id:06d} in frame {frame_id}."
        )

    y, x = position

    # CAP_PROP_POS_FRAMES is the zero-based index of the next frame to decode.
    cap = cv2.VideoCapture(str(VIDEO_PATH))
    try:
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_id)
        ok, frame = cap.read()
    finally:
        cap.release()

    if not ok or frame is None:
        raise ValueError(f"Could not read frame {frame_id} from {VIDEO_PATH.name}.")

    # Coordinates are rounded to the closest pixel.
    center_x = int(round(x))
    center_y = int(round(y))
    half = cutout_size // 2

    # Output stays exactly cutout_size x cutout_size even near an edge.
    patch = np.zeros((cutout_size, cutout_size, 3), dtype=frame.dtype)

    src_x0 = max(0, center_x - half)
    src_y0 = max(0, center_y - half)
    src_x1 = min(frame.shape[1], center_x - half + cutout_size)
    src_y1 = min(frame.shape[0], center_y - half + cutout_size)

    dst_x0 = src_x0 - (center_x - half)
    dst_y0 = src_y0 - (center_y - half)
    dst_x1 = dst_x0 + (src_x1 - src_x0)
    dst_y1 = dst_y0 + (src_y1 - src_y0)

    patch[dst_y0:dst_y1, dst_x0:dst_x1] = frame[src_y0:src_y1, src_x0:src_x1]

    return patch

def get_bee_orientation(bee_id: int, frame_id: int, TRAJECTORY_DIR: Path) -> int:
    """Return the stored orientation_angle for one bee in one frame."""
    trajectory_path = TRAJECTORY_DIR / f"{bee_id:06d}.txt"

    with trajectory_path.open("r", newline="") as f:
        reader = csv.reader(f, skipinitialspace=True)

        for row in reader:
            if not row or row[0].strip().startswith("#"):
                continue

            if int(row[0]) == frame_id:
                # row: frame_id, pos_x, pos_y, object_class, orientation_angle
                return int(row[4])

    raise ValueError(
        f"No orientation found for bee {bee_id:06d} in frame {frame_id}."
    )


def get_bee_cutout_with_orientation(
    bee_id: int,
    frame_id: int,
    TRAJECTORY_DIR: Path,
    VIDEO_PATH: Path,
    cutout_size: int = 100,
    arrow_length: int = 35,
) -> None:
    """
    Show a 100x100 bee cutout with a red orientation arrow.

    Assumed angle convention:
      0   -> right
      65  -> down
      130 -> left
      195 -> up
      259 -> almost right again

    Change the conversion below if your tracking data uses another
    orientation convention.
    """
    # Your existing function now returns a grayscale 2D image:
    # shape: (100, 100)

    orientation_angle = get_bee_orientation(bee_id = bee_id, frame_id = frame_id, TRAJECTORY_DIR = TRAJECTORY_DIR)

    # Convert grayscale to BGR so a red arrow can be drawn.
    image_with_arrow = bee_cutout(
        TRAJECTORY_DIR=TRAJECTORY_DIR,
        VIDEO_PATH=VIDEO_PATH,
        bee_id=bee_id,
        frame_id=frame_id,
        cutout_size=cutout_size,
    )
    
    angle_radians = 2 * math.pi * orientation_angle / 360 - math.pi / 2

    center_x = cutout_size // 2
    center_y = cutout_size // 2

    # Image y coordinates grow downward, hence +sin(...) for y.
    end_x = int(round(center_x + arrow_length * math.cos(angle_radians)))
    end_y = int(round(center_y + arrow_length * math.sin(angle_radians)))

    cv2.arrowedLine(
        image_with_arrow,
        (center_x, center_y),
        (end_x, end_y),
        color=(0, 0, 255),  # Red in OpenCV BGR
        thickness=2,
        line_type=cv2.LINE_AA,
        tipLength=0.25,
    )

    return image_with_arrow
    cv2.imshow(
        f"Bee {bee_id:06d}, frame {frame_id}, angle {orientation_angle}",
        image_with_arrow,
    )
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def angular_difference(angle_a: int, angle_b: int) -> int:
    return abs((angle_b - angle_a + 180) % 360 - 180)


def add_orientation_arrow(
    gray_cutout: np.ndarray,
    orientation_angle: int,
    arrow_length: int = 35,
    arrow_thickness: int = 2,
) -> np.ndarray:
    """
    Convert a grayscale cutout to BGR and draw its orientation as a red arrow.

    Assumes 0° = right, 90° = down, 180° = left, 270° = up.
    """
    image = gray_cutout.copy()

    height, width = gray_cutout.shape[:2]
    center_x, center_y = width // 2, height // 2

    angle_rad = math.radians(orientation_angle - 90)

    end_x = int(round(center_x + arrow_length * math.cos(angle_rad)))
    end_y = int(round(center_y + arrow_length * math.sin(angle_rad)))

    cv2.arrowedLine(
        image,
        (center_x, center_y),
        (end_x, end_y),
        color=(0, 0, 255),  # Red in OpenCV BGR format
        thickness=arrow_thickness,
        line_type=cv2.LINE_AA,
        tipLength=0.25,
    )

    return image


def make_labeled_pair(
    bee_id: int,
    frame_left: int,
    angle_left: int,
    frame_right: int,
    TRAJECTORY_DIR: Path,
    VIDEO_PATH: Path,
    angle_right: int,
    display_scale:float = 3,
) -> np.ndarray:
    """
    Create one review image: first frame left, next frame right.
    """
    left_gray = bee_cutout(
        bee_id, frame_left,
        TRAJECTORY_DIR=TRAJECTORY_DIR,
        VIDEO_PATH=VIDEO_PATH,
        )
    right_gray = bee_cutout(
        bee_id, frame_right,
        TRAJECTORY_DIR=TRAJECTORY_DIR,
        VIDEO_PATH=VIDEO_PATH,
        )

    left_image = add_orientation_arrow(left_gray, angle_left)
    right_image = add_orientation_arrow(right_gray, angle_right)

    left_image = cv2.resize(
        left_image,
        None,
        fx=display_scale,
        fy=display_scale,
        interpolation=cv2.INTER_CUBIC,
    )
    right_image = cv2.resize(
        right_image,
        None,
        fx=display_scale,
        fy=display_scale,
        interpolation=cv2.INTER_CUBIC,
    )
    scaled_size = 100 * display_scale

    # Separator must have the same height as the enlarged images.
    separator = np.full((scaled_size, 5, 3), 255, dtype=np.uint8)
    images = cv2.hconcat([left_image, separator, right_image])

    # Header remains exactly the original height and font size.
    header = np.zeros((55, images.shape[1], 3), dtype=np.uint8)
    
    cv2.putText(
        header,
        f"Bee {bee_id:06d} | orientation change: "
        f"{angular_difference(angle_left, angle_right)} deg",
        (5, 18),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.45,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )

    cv2.putText(
        header,
        f"LEFT: frame {frame_left}, {angle_left} deg",
        (5, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )

    cv2.putText(
        header,
        f"RIGHT: frame {frame_right}, {angle_right} deg",
        (scaled_size + 10, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )

    return cv2.vconcat([header, images])

def flip_orientation_run(
    track_rows: list[dict],
    rows: list[list[str]],
    seed_indices: list[int],
    similarity_tolerance: int = 7,
) -> list[dict]:
    """
    Flip each seed row and any adjacent, consecutive-frame rows whose
    original orientations differ by at most similarity_tolerance degrees.

    Propagation rules:
    - A seed expands rightward through orientations similar to the prior frame.
    - A seed expands leftward through orientations similar to the next frame.
    - Every selected row is flipped exactly once, even if two expansions overlap.

    Returns records sufficient to undo the complete propagated correction.
    """
    # Keep orientations before changing anything. This is essential:
    # comparisons must use the original annotation chain, not already-flipped values.
    original_angles = [item["orientation"] for item in track_rows]
    indices_to_flip = set(seed_indices)

    for seed_index in seed_indices:
        # Expand right: compare each candidate to its preceding frame.
        index = seed_index + 1
        while index < len(track_rows):
            previous = track_rows[index - 1]
            current = track_rows[index]

            if current["frame_id"] != previous["frame_id"] + 1:
                break

            if angular_difference(
                original_angles[index],
                original_angles[index - 1],
            ) > similarity_tolerance:
                break

            indices_to_flip.add(index)
            index += 1

        # Expand left: compare each candidate to its following frame.
        index = seed_index - 1
        while index >= 0:
            current = track_rows[index]
            following = track_rows[index + 1]

            if following["frame_id"] != current["frame_id"] + 1:
                break

            if angular_difference(
                original_angles[index],
                original_angles[index + 1],
            ) > similarity_tolerance:
                break

            indices_to_flip.add(index)
            index -= 1

    # Save every changed item so 'b' can restore the whole propagated run.
    undo_items = []

    for index in sorted(indices_to_flip):
        item = track_rows[index]
        row = rows[item["row_index"]]
        old_angle = int(float(row[4])) % 360
        new_angle = (old_angle + 180) % 360

        undo_items.append({
            "row_index": item["row_index"],
            "old_angle": old_angle,
            "track_row": item,
        })

        row[4] = str(new_angle)
        item["orientation"] = new_angle

    return undo_items

def review_orientation_changes(
    IMPROVED_TRAJECTORY_DIR: Path,
    TRAJECTORY_DIR: Path,
    VIDEO_PATH: Path,
    error_tolerance: int = 20,
    quit_key: str = "q",
) -> None:
    """
    Review likely 180-degree orientation errors.

    Keys:
    a : Left is correct; flip right by 180°.
    l : Right is correct; flip left by 180°.
    t : Both are incorrect; flip both by 180°.
    u : Both are correct; change neither.
    b : Go back once, undo the prior decision, and review that pair again.
    q : Stop and save all changes made so far.
    """
    if not 0 <= error_tolerance <= 180:
        raise ValueError("error_tolerance must be between 0 and 180.")

    threshold = 180 - error_tolerance
    IMPROVED_TRAJECTORY_DIR.mkdir(parents=True, exist_ok=True)

    trajectory_files = sorted(IMPROVED_TRAJECTORY_DIR.glob("*.txt"))
    if not trajectory_files:
        raise FileNotFoundError(
            f"No .txt trajectory files found in {IMPROVED_TRAJECTORY_DIR}"
        )

    total_candidates = 0
    total_flipped_rows = 0
    stopped_early = False

    # This holds exactly one prior decision, allowing one-level undo.
    previous_decision = None

    window_name = (
        "a: left correct | l: right correct | t: both wrong | "
        "u: both right | b: undo once | q: quit"
    )

    for trajectory_path in trajectory_files:
        bee_id = int(trajectory_path.stem)

        rows = []
        track_rows = []

        with trajectory_path.open("r", newline="") as f:
            reader = csv.reader(f, skipinitialspace=True)

            for row_index, row in enumerate(reader):
                rows.append(row)

                if not row or row[0].strip().startswith("#"):
                    continue

                try:
                    frame_id = int(row[0])
                    orientation = int(float(row[4])) % 360
                except (ValueError, IndexError):
                    continue

                track_rows.append({
                    "row_index": row_index,
                    "frame_id": frame_id,
                    "orientation": orientation,
                })

        pair_index = 0

        while pair_index < len(track_rows) - 1:
            previous = track_rows[pair_index]
            current = track_rows[pair_index + 1]

            # Only inspect immediately consecutive video frames.
            if current["frame_id"] != previous["frame_id"] + 1:
                pair_index += 1
                continue

            difference = angular_difference(
                previous["orientation"],
                current["orientation"],
            )

            if difference < threshold:
                pair_index += 1
                continue

            total_candidates += 1

            review_image = make_labeled_pair(
                bee_id=bee_id,
                frame_left=previous["frame_id"],
                angle_left=previous["orientation"],
                frame_right=current["frame_id"],
                angle_right=current["orientation"],
                TRAJECTORY_DIR=TRAJECTORY_DIR,
                VIDEO_PATH=VIDEO_PATH,
            )

            cv2.imshow(window_name, review_image)

            while True:
                pressed = chr(cv2.waitKey(0) & 0xFF).lower()

                if pressed in {"a", "l", "t", "u", "b", quit_key.lower()}:
                    break

            if pressed == quit_key.lower():
                stopped_early = True
                break

            # Undo only the immediately prior accepted decision.
            if pressed == "b":
                if previous_decision is None:
                    print("Nothing to undo yet.")
                    continue

                # Restore the prior orientation values in both rows.
                for item in previous_decision["items"]:
                    row = rows[item["row_index"]]
                    row[4] = str(item["old_angle"])
                    item["track_row"]["orientation"] = item["old_angle"]

                total_flipped_rows -= previous_decision["flips_made"]

                # Return to the previous candidate pair only once.
                if (
                    previous_decision["trajectory_path"] == trajectory_path
                    and previous_decision["pair_index"] < pair_index
                ):
                    pair_index = previous_decision["pair_index"]
                else:
                    print(
                        "The previous decision was in a different file; "
                        "it was restored but cannot be redisplayed here."
                    )

                previous_decision = None
                continue
            # Select the trajectory-row index or indices that are certainly wrong.
            # In this pair, `previous` is the left image and `current` is the right.
            seed_indices = []

            if pressed == "a":
                # Left is correct -> right is wrong.
                seed_indices = [pair_index + 1]

            elif pressed == "l":
                # Right is correct -> left is wrong.
                seed_indices = [pair_index]

            elif pressed == "t":
                # Both labels are wrong; each side propagates outward.
                seed_indices = [pair_index, pair_index + 1]

            # "u": both are right, therefore no correction or propagation.
            if seed_indices:
                undo_items = flip_orientation_run(
                    track_rows=track_rows,
                    rows=rows,
                    seed_indices=seed_indices,
                    similarity_tolerance=10,
                )
            else:
                undo_items = []

            total_flipped_rows += len(undo_items)

            # Preserve the *complete* propagation result for one-level undo via 'b'.
            previous_decision = {
                "trajectory_path": trajectory_path,
                "pair_index": pair_index,
                "rows": rows,
                "items": undo_items,
                "flips_made": len(undo_items),
            }

            pair_index += 1

        # Save the corrected version of this bee's trajectory.
        output_path = IMPROVED_TRAJECTORY_DIR / trajectory_path.name
        with output_path.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(rows)

        if stopped_early:
            break

    cv2.destroyAllWindows()

    print(
        f"Reviewed {total_candidates} candidate pairs. "
        f"Changed {total_flipped_rows} orientation labels. "
        f"Saved output to: {IMPROVED_TRAJECTORY_DIR}"
    )

def reset_improved_from_frame(
    original_dir: Path,
    improved_dir: Path,
    start_frame: int = 1950,
) -> None:
    """
    Restore all trajectory rows from `start_frame` onward in improved_dir,
    using the matching file from original_dir.

    Example:
        improved_data/000012.txt rows with frame_id >= 1950
        are replaced by the corresponding original_data rows from
        rec1_trajectories/000012.txt.

    Rows with frame_id < start_frame are kept from improved_data.
    """
    if not original_dir.is_dir():
        raise FileNotFoundError(f"Original trajectory directory not found: {original_dir}")

    if not improved_dir.is_dir():
        raise FileNotFoundError(f"Improved trajectory directory not found: {improved_dir}")

    changed_files = 0
    replaced_rows = 0

    for original_path in sorted(original_dir.glob("*.txt")):
        improved_path = improved_dir / original_path.name

        if not improved_path.exists():
            print(f"Skipping {original_path.name}: no improved file exists.")
            continue

        # Map original frame ID -> original complete row.
        original_rows_by_frame = {}

        with original_path.open("r", newline="") as f:
            for row in csv.reader(f, skipinitialspace=True):
                if not row or row[0].strip().startswith("#"):
                    continue

                try:
                    frame_id = int(row[0])
                except ValueError:
                    # Allows a possible non-comment header row.
                    continue

                original_rows_by_frame[frame_id] = row

        # Read improved rows and replace only the requested time range.
        updated_rows = []
        file_replacements = 0

        with improved_path.open("r", newline="") as f:
            for row in csv.reader(f, skipinitialspace=True):
                if not row or row[0].strip().startswith("#"):
                    updated_rows.append(row)
                    continue

                try:
                    frame_id = int(row[0])
                except ValueError:
                    updated_rows.append(row)  # Preserve a possible header row.
                    continue

                if frame_id >= start_frame and frame_id in original_rows_by_frame:
                    updated_rows.append(original_rows_by_frame[frame_id])
                    file_replacements += 1
                else:
                    updated_rows.append(row)

        # Overwrite the improved file only if it actually changed.
        if file_replacements > 0:
            with improved_path.open("w", newline="") as f:
                writer = csv.writer(f)
                writer.writerows(updated_rows)

            changed_files += 1
            replaced_rows += file_replacements

    print(
        f"Reset {replaced_rows} rows in {changed_files} improved trajectory files "
        f"from frame {start_frame} onward."
    )
def load_all_trajectories(
    IMPROVED_TRAJECTORY_DIR: Path,    
        ):
    """
    Load all trajectory files once.

    Returns
    -------
    trajectories : dict[int, dict]
        One entry per bee, containing:
        - rows: all original CSV rows, for writing output
        - by_frame: {frame_id: tracking_item}
        - ordered: tracking items in increasing frame order
    """
    trajectories = {}

    for trajectory_path in sorted(IMPROVED_TRAJECTORY_DIR.glob("*.txt")):
        bee_id = int(trajectory_path.stem)

        rows = []
        ordered = []
        by_frame = {}

        with trajectory_path.open("r", newline="") as f:
            reader = csv.reader(f, skipinitialspace=True)

            for row_index, row in enumerate(reader):
                rows.append(row)

                if not row or row[0].strip().startswith("#"):
                    continue

                try:
                    frame_id = int(row[0])
                    tracked_row = float(row[1])  # Stored as pos_x, actually row/y
                    tracked_col = float(row[2])  # Stored as pos_y, actually column/x
                    orientation = int(float(row[4])) % 360
                except (ValueError, IndexError):
                    continue

                item = {
                    "row_index": row_index,
                    "frame_id": frame_id,
                    "tracked_row": tracked_row,
                    "tracked_col": tracked_col,
                    "orientation": orientation,
                }

                ordered.append(item)
                by_frame[frame_id] = item

        ordered.sort(key=lambda item: item["frame_id"])

        trajectories[bee_id] = {
            "path": trajectory_path,
            "rows": rows,
            "ordered": ordered,
            "by_frame": by_frame,
        }

    return trajectories


def cutout_from_cached_frame(
    gray_frame: np.ndarray,
    tracked_row: float,
    tracked_col: float,
    cutout_size: int = 100,
) -> np.ndarray:
    """
    Return a grayscale cutout from an already decoded grayscale frame.

    The trajectory coordinates are stored as:
    pos_x -> image row (y)
    pos_y -> image column (x)
    """
    center_y = int(round(tracked_row))
    center_x = int(round(tracked_col))

    half = cutout_size // 2

    patch = np.zeros((cutout_size, cutout_size), dtype=gray_frame.dtype)

    source_x0 = max(0, center_x - half)
    source_y0 = max(0, center_y - half)
    source_x1 = min(gray_frame.shape[1], center_x - half + cutout_size)
    source_y1 = min(gray_frame.shape[0], center_y - half + cutout_size)

    destination_x0 = source_x0 - (center_x - half)
    destination_y0 = source_y0 - (center_y - half)
    destination_x1 = destination_x0 + (source_x1 - source_x0)
    destination_y1 = destination_y0 + (source_y1 - source_y0)

    patch[
        destination_y0:destination_y1,
        destination_x0:destination_x1,
    ] = gray_frame[source_y0:source_y1, source_x0:source_x1]

    return patch


def make_labeled_cached_pair(
    bee_id: int,
    left_frame_id: int,
    left_item: dict,
    left_gray_frame: np.ndarray,
    right_frame_id: int,
    right_item: dict,
    right_gray_frame: np.ndarray,
    display_scale: int = 3,
) -> np.ndarray:
    """
    Build the review display from the two already cached video frames.
    """
    left_cutout = cutout_from_cached_frame(
        left_gray_frame,
        left_item["tracked_row"],
        left_item["tracked_col"],
    )
    right_cutout = cutout_from_cached_frame(
        right_gray_frame,
        right_item["tracked_row"],
        right_item["tracked_col"],
    )

    left_image = add_orientation_arrow(
        left_cutout,
        left_item["orientation"],
    )
    right_image = add_orientation_arrow(
        right_cutout,
        right_item["orientation"],
    )

    left_image = cv2.resize(
        left_image,
        None,
        fx=display_scale,
        fy=display_scale,
        interpolation=cv2.INTER_CUBIC,
    )
    right_image = cv2.resize(
        right_image,
        None,
        fx=display_scale,
        fy=display_scale,
        interpolation=cv2.INTER_CUBIC,
    )


    image_height = left_image.shape[0]
    separator = np.full((image_height, 5), 255, dtype=np.uint8)
    images = np.concatenate(
    [left_image, separator, right_image],
    axis=1,
)

    # Header/text is intentionally NOT scaled.
    header = np.zeros((55, images.shape[1]), dtype=np.uint8)

    change = angular_difference(
        left_item["orientation"],
        right_item["orientation"],
    )

    cv2.putText(
        header,
        f"Bee {bee_id:06d} | orientation change: {change} deg",
        (5, 18),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.45,
        255,
        1,
        cv2.LINE_AA,
    )

    cv2.putText(
        header,
        f"LEFT: frame {left_frame_id}, {left_item['orientation']} deg",
        (5, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        255,
        1,
        cv2.LINE_AA,
    )

    cv2.putText(
        header,
        f"RIGHT: frame {right_frame_id}, {right_item['orientation']} deg",
        (100 * display_scale + 10, 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        255,
        1,
        cv2.LINE_AA,
    )
    return np.concatenate(
        [header, images],
        axis=0,
    )
    return cv2.vconcat([header, images])


def flip_item(item: dict, rows: list[list[str]]) -> dict:
    """
    Flip one orientation by 180 degrees and return undo information.
    """
    row = rows[item["row_index"]]
    old_angle = int(float(row[4])) % 360
    new_angle = (old_angle + 180) % 360

    row[4] = str(new_angle)
    item["orientation"] = new_angle

    return {
        "item": item,
        "old_angle": old_angle,
    }


def flip_similar_run(
    trajectory: dict,
    seed_frame_id: int,
    direction: str,
    similarity_tolerance: int = 10,
) -> list[dict]:
    """
    Flip a seed frame and its similarly oriented consecutive run.

    direction="right":
        Flip seed, then later frames while each frame differs by <= 10°
        from the preceding frame, using orientations before this correction.

    direction="left":
        Flip seed, then earlier frames while each frame differs by <= 10°
        from the following frame, using orientations before this correction.

    Returns undo records for every modified orientation.
    """
    ordered = trajectory["ordered"]
    rows = trajectory["rows"]

    index_by_frame = {
        item["frame_id"]: index
        for index, item in enumerate(ordered)
    }

    if seed_frame_id not in index_by_frame:
        return []

    seed_index = index_by_frame[seed_frame_id]

    # Snapshot BEFORE changing labels, so propagation remains meaningful.
    original_angles = [item["orientation"] for item in ordered]

    indices_to_flip = {seed_index}

    if direction == "right":
        index = seed_index + 1

        while index < len(ordered):
            preceding = ordered[index - 1]
            current = ordered[index]

            if current["frame_id"] != preceding["frame_id"] + 1:
                break

            if angular_difference(
                original_angles[index],
                original_angles[index - 1],
            ) > similarity_tolerance:
                break

            indices_to_flip.add(index)
            index += 1

    elif direction == "left":
        index = seed_index - 1

        while index >= 0:
            current = ordered[index]
            following = ordered[index + 1]

            if following["frame_id"] != current["frame_id"] + 1:
                break

            if angular_difference(
                original_angles[index],
                original_angles[index + 1],
            ) > similarity_tolerance:
                break

            indices_to_flip.add(index)
            index -= 1

    else:
        raise ValueError("direction must be 'left' or 'right'.")

    undo_records = []

    for index in sorted(indices_to_flip):
        undo_records.append(flip_item(ordered[index], rows))

    return undo_records


def save_improved_trajectories(
        trajectories: dict[int, dict],
        IMPROVED_TRAJECTORY_DIR: Path
    ) -> None:
    """Write the current in-memory trajectories to improved_data."""
    IMPROVED_TRAJECTORY_DIR.mkdir(parents=True, exist_ok=True)

    for trajectory in trajectories.values():
        output_path = IMPROVED_TRAJECTORY_DIR / trajectory["path"].name

        with output_path.open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(trajectory["rows"])

def set_type_one_discontinuity_run(
    trajectory: dict,
    left_frame_id: int,
    right_frame_id: int,
    divergence_threshold: int = 90,
) -> list[dict]:
    """
    Set object class/type to 1 for the inspected left and right frames.

    Then propagate:
    - backward from the left frame while each frame differs from its next
      frame by at least `divergence_threshold` degrees;
    - forward from the right frame while each frame differs from its previous
      frame by at least `divergence_threshold` degrees.

    The orientation labels themselves are not changed.

    Returns undo records, should you later want to add undo support for `c`.
    """
    ordered = trajectory["ordered"]
    rows = trajectory["rows"]

    index_by_frame = {
        item["frame_id"]: index
        for index, item in enumerate(ordered)
    }

    if left_frame_id not in index_by_frame:
        raise ValueError(f"Left frame {left_frame_id} was not found.")
    if right_frame_id not in index_by_frame:
        raise ValueError(f"Right frame {right_frame_id} was not found.")

    left_index = index_by_frame[left_frame_id]
    right_index = index_by_frame[right_frame_id]

    # The two frames currently displayed are always changed to type 1.
    indices_to_mark = {left_index, right_index}

    # Expand backward from the left displayed frame.
    index = left_index - 1

    while index >= 0:
        current = ordered[index]
        following = ordered[index + 1]

        # Do not propagate across missing-frame gaps.
        if following["frame_id"] != current["frame_id"] + 1:
            break

        difference = angular_difference(
            current["orientation"],
            following["orientation"],
        )

        # Keep moving only through large orientation discontinuities.
        if difference < divergence_threshold:
            break

        indices_to_mark.add(index)
        index -= 1

    # Expand forward from the right displayed frame.
    index = right_index + 1

    while index < len(ordered):
        preceding = ordered[index - 1]
        current = ordered[index]

        # Do not propagate across missing-frame gaps.
        if current["frame_id"] != preceding["frame_id"] + 1:
            break

        difference = angular_difference(
            current["orientation"],
            preceding["orientation"],
        )

        # Keep moving only through large orientation discontinuities.
        if difference < divergence_threshold:
            break

        indices_to_mark.add(index)
        index += 1

    # Set the fourth CSV column: object class/type.
    undo_records = []

    for index in sorted(indices_to_mark):
        item = ordered[index]
        row = rows[item["row_index"]]

        old_type = row[3].strip()
        row[3] = "1"

        undo_records.append({
            "item": item,
            "old_type": old_type,
        })

    return undo_records

def review_orientation_changes_framewise(
    TRAJECTORY_DIR: Path,
    VIDEO_PATH: Path,
    IMPROVED_TRAJECTORY_DIR: Path,
    error_tolerance: int = 20,
    similarity_tolerance: int = 10,
    display_scale: int = 3,
    trajectory_frame_offset: int = 0,
    start_frame: int  = 0,
) -> None:
    """
    Review all bees frame by frame using sequential video decoding.

    `trajectory_frame_offset`:
    - Use 0 if trajectory IDs and video frame indices both begin at 0.
    - Use 1 if trajectory IDs begin at 1 but the video begins at 0.

    Keyboard controls:
    a : Left is correct; right is wrong. Flip right and similar later frames.
    l : Right is correct; left is wrong. Flip left and similar earlier frames.
    t : Both are wrong. Flip leftward run and rightward run.
    u : Both are correct. Do nothing.
    q : Stop review and save all changes made so far.
    """
    if not 0 <= error_tolerance <= 180:
        raise ValueError("error_tolerance must be between 0 and 180.")

    if not 0 <= similarity_tolerance <= 180:
        raise ValueError("similarity_tolerance must be between 0 and 180.")

    threshold = 180 - error_tolerance
    trajectories = load_all_trajectories()

    if not trajectories:
        raise FileNotFoundError(f"No .txt files found in {TRAJECTORY_DIR}")

    cap = cv2.VideoCapture(str(VIDEO_PATH))
    if not cap.isOpened():
        raise FileNotFoundError(f"Could not open video: {VIDEO_PATH}")
    
    if start_frame < 0:
        raise ValueError("start_frame must be >= 0.")

    # Convert a trajectory frame ID into the corresponding MP4 frame index.
    # Example: offset=1 means trajectory frame 1 corresponds to video frame 0.
    start_video_index = start_frame - trajectory_frame_offset

    if start_video_index < 0:
        raise ValueError(
            f"start_frame={start_frame} is invalid for "
            f"trajectory_frame_offset={trajectory_frame_offset}."
        )

    # Make the NEXT cap.read() return the requested starting video frame.
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_video_index)

    ok, previous_bgr = cap.read()
    if not ok or previous_bgr is None:
        raise ValueError(
            f"Could not read video frame {start_video_index} "
            f"(trajectory frame {start_frame})."
        )

    # Keep frames grayscale and arrows/text white.
    previous_gray = cv2.cvtColor(previous_bgr, cv2.COLOR_BGR2GRAY)

    # This is the MP4 index of `previous_gray`.
    video_index = start_video_index

    window_name = (
        "a: left correct | l: right correct | t: both wrong | "
        "u: both right | q: save and quit"
    )

    reviewed_candidates = 0
    changed_orientations = 0
    stopped_early = False

    try:
        # Decode video frame 0 once.
        ok, previous_bgr = cap.read()
        if not ok:
            raise ValueError("Could not read the first video frame.")

        previous_gray = cv2.cvtColor(previous_bgr, cv2.COLOR_BGR2GRAY)
        video_index = 0

        while True:
            # Decode only the next video frame. These are the two-frame cache.
            ok, current_bgr = cap.read()
            if not ok:
                break

            current_gray = cv2.cvtColor(current_bgr, cv2.COLOR_BGR2GRAY)

            left_frame_id = video_index + trajectory_frame_offset
            right_frame_id = left_frame_id + 1

            # At this particular frame transition, inspect every bee.
            for bee_id in sorted(trajectories):
                trajectory = trajectories[bee_id]

                left_item = trajectory["by_frame"].get(left_frame_id)
                right_item = trajectory["by_frame"].get(right_frame_id)

                # This bee may not be present in both frames.
                if left_item is None or right_item is None:
                    continue

                difference = angular_difference(
                    left_item["orientation"],
                    right_item["orientation"],
                )

                if difference < threshold:
                    continue

                reviewed_candidates += 1

                review_image = make_labeled_cached_pair(
                    bee_id=bee_id,
                    left_frame_id=left_frame_id,
                    left_item=left_item,
                    left_gray_frame=previous_gray,
                    right_frame_id=right_frame_id,
                    right_item=right_item,
                    right_gray_frame=current_gray,
                    display_scale=display_scale,
                )

                cv2.imshow(window_name, review_image)

                while True:
                    key = cv2.waitKey(0) & 0xFF
                    pressed = chr(key).lower()
                    if pressed in {"a", "l", "t", "u", "c", "q"}:
                        break

                if pressed == "q":
                    stopped_early = True
                    break

                if pressed == "a":
                    # Right label is wrong: flip it and its similar future run.
                    changes = flip_similar_run(
                        trajectory,
                        seed_frame_id=right_frame_id,
                        direction="right",
                        similarity_tolerance=similarity_tolerance,
                    )
                    changed_orientations += len(changes)

                elif pressed == "l":
                    # Left label is wrong: flip it and its similar past run.
                    changes = flip_similar_run(
                        trajectory,
                        seed_frame_id=left_frame_id,
                        direction="left",
                        similarity_tolerance=similarity_tolerance,
                    )
                    changed_orientations += len(changes)

                elif pressed == "t":
                    # Two separate runs avoid flipping a correct region
                    # across the 180-degree discontinuity.
                    left_changes = flip_similar_run(
                        trajectory,
                        seed_frame_id=left_frame_id,
                        direction="left",
                        similarity_tolerance=similarity_tolerance,
                    )

                    right_changes = flip_similar_run(
                        trajectory,
                        seed_frame_id=right_frame_id,
                        direction="right",
                        similarity_tolerance=similarity_tolerance,
                    )

                    changed_orientations += len(left_changes) + len(right_changes)
                elif pressed == "c":
                    type_changes = set_type_one_discontinuity_run(
                        trajectory=trajectory,
                        left_frame_id=left_frame_id,
                        right_frame_id=right_frame_id,
                        divergence_threshold=90,
                    )
                # "u": no correction.

            if stopped_early:
                break

            # Advance the two-frame cache by one frame.
            previous_gray = current_gray
            video_index += 1

    finally:
        cap.release()
        cv2.destroyAllWindows()

    save_improved_trajectories(trajectories)

    print(
        f"Reviewed {reviewed_candidates} candidate transitions. "
        f"Flipped {changed_orientations} orientations. "
        f"Saved trajectories to: {IMPROVED_TRAJECTORY_DIR}"
    )
